# bitly
this was created using SSH; starting from here - https://help.github.com/articles/checking-for-existing-ssh-keys/ to finally changing the current working directory to your local project and following the directions from the remote repo.
